util.AddNetworkString("TicSys.notify")
util.AddNetworkString("TicSys.updateTicket")

function TicSys:newTicket(ply, ticket)
	if !TicSys:canCreateTicket(ply) then return end
	
	sql.Query("INSERT INTO ts_tickets(caller, violator, isSolved, description, rating, timeOpen, url, shortReason) VALUES("..sql.SQLStr(util.TableToJSON(ticket.caller))..", "..sql.SQLStr(util.TableToJSON(ticket.violator))..", 0, "..sql.SQLStr(ticket.description)..", -1, "..sql.SQLStr(os.time())..", "..sql.SQLStr(util.TableToJSON(ticket.url))..", "..sql.SQLStr(ticket.shortReason)..")")
	
	local lastLine = sql.Query("SELECT * FROM ts_tickets WHERE id=(SELECT MAX(id) FROM ts_tickets)")
	TicSys:updateTicket(false, lastLine[1])

	timer.Create("recoilTicketCreation"..ply:UserID(), TicSys.cfg["Recoil Ticket Creation"], 1, function() end)

	for k,v in pairs(player.GetAll()) do
		if TicSys:isOwner(v) || TicSys:isAdmin(v) then
			local violatorName = lastLine[1].violator.name != "" and lastLine[1].violator.name or lastLine[1].violator.otherinfo

			local msg = string.Replace(TicSys.lang["ntf.New Ticket"],"%CALLER",lastLine[1].caller.name)
			msg = string.Replace(msg,"%VIOLATOR",string.len(violatorName) <= 12 and violatorName or string.sub(violatorName, 1, 12))
			msg = string.Replace(msg,"%REASON",string.len(lastLine[1].shortReason) <= 12 and lastLine[1].shortReason or string.sub(lastLine[1].shortReason, 1, 12))

			TicSys:notify(v, msg, 0, lastLine[1].id)
		end
	end
end

function TicSys:setNetTickets()
	local timeLoad = os.time() - (TicSys.cfg["Load Ticket Last ? Days"]*86400)
	local result = sql.Query("SELECT * FROM ts_tickets WHERE timeOpen > "..sql.SQLStr(timeLoad))
	if result == nil then result = {} end
	for k,v in pairs(result) do
		TicSys:JSONToTable(v)
	end
	local tableCompress = util.Compress(util.TableToJSON(result))
	return net.WriteUInt(#tableCompress, 32), net.WriteData(tableCompress, #tableCompress)
end

function TicSys:changeCommand(newCommand)
	concommand.Remove(self.cfg["Command"])
	concommand.Add(newCommand, function(ply, cmd, args)
		net.Start("TicSys.openMenu")
		self:setNetTickets()
		net.Send(ply)
	end)
	self.cfg["Command"] = newCommand
end

function TicSys:JSONToTable(tbl)
	tbl.caller = util.JSONToTable(tbl.caller)
	tbl.verifier = util.JSONToTable(tbl.verifier)
	tbl.violator = util.JSONToTable(tbl.violator)
	tbl.url = util.JSONToTable(tbl.url)
end

function TicSys:updateTicket(id, tbl)
	if id then
		local result = sql.Query("SELECT * FROM ts_tickets WHERE id="..sql.SQLStr(id))
		if result != nil then
			TicSys:JSONToTable(result[1])

			net.Start("TicSys.updateTicket")
			net.WriteTable(result[1])
			net.Broadcast()
		end
	elseif tbl then
		TicSys:JSONToTable(tbl)

		net.Start("TicSys.updateTicket")
		net.WriteTable(tbl)
		net.Broadcast()
	end
end

function TicSys:reloadCfg(isAll, ply)
	if isAll then
		net.Start("TicSys.reloadCfg")
		net.WriteTable(TicSys.cfg)
		net.WriteTable(TicSys.lang)
		net.Broadcast()
	elseif IsValid(ply) then
		net.Start("TicSys.reloadCfg")
		net.WriteTable(TicSys.cfg)
		net.WriteTable(TicSys.lang)
		net.Send(ply)
	end
end

function TicSys:notify(ply, msg, ntf_type, id)
	if IsValid(ply) && ply:GetNWBool("isTicSysNotify") then
		net.Start("TicSys.notify")
		net.WriteString(msg)
		net.WriteInt(ntf_type, 3)
		if id then
			net.WriteInt(id, 16)
		else
			net.WriteInt(0, 16)
		end
		net.Send(ply)
	end
end

function TicSys:canCreateTicket(ply)
	if timer.Exists("recoilTicketCreation"..ply:UserID()) then
		local msg = TicSys.lang["ntf.Recoil Ticket Creation"].." "..math.ceil(timer.TimeLeft("recoilTicketCreation"..ply:UserID())).." "..TicSys.lang["Seconds"]
		TicSys:notify(ply, msg, 2)
		return false
	end
	TicSys:notify(ply, TicSys.lang["ntf.Successfully Create Ticket"], 1)
	return true
end