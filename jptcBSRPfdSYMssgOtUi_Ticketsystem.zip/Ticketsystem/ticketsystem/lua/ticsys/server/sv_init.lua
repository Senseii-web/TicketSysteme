hook.Add("Initialize","TicSys.defaultSettings",function()
	if !file.IsDir("ticketsystem", "DATA") then
		file.CreateDir("ticketsystem", "DATA")
	end

	if !file.Exists("ticketsystem/settings.txt", "DATA") then
		file.Write("ticketsystem/settings.txt", util.TableToJSON(TicSys.defaultSettings))

		TicSys.lang = TicSys.defaultSettings.language
		TicSys.cfg = TicSys.defaultSettings.config
	else
		local settings = util.JSONToTable(file.Read("ticketsystem/settings.txt"))

		for k,v in pairs(TicSys.defaultSettings.config) do
			if !settings.config[k] then
				settings.config[k] = v
			end
		end
		for k,v in pairs(TicSys.defaultSettings.language) do
			if !settings.language[k] then
				settings.language[k] = v
			end
		end
		file.Write("ticketsystem/settings.txt", util.TableToJSON(settings))
		
		TicSys.lang = settings.language
		TicSys.cfg = settings.config
	end

	sql.Query("CREATE TABLE IF NOT EXISTS ts_tickets(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, caller TEXT, violator TEXT, verifier TEXT, timeOpen INTEGER, timeClosed INTEGER, timeTaked INTEGER, isSolved INTEGER, description TEXT, shortReason VARCHAR(255), rating FLOAT, url TEXT)")

	TicSys:changeCommand(TicSys.cfg["Command"])
end)