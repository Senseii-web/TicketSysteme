util.AddNetworkString("TicSys.openMenu")
util.AddNetworkString("TicSys.reloadCfg")

hook.Add("PlayerSay","TicSys.openMenu",function(ply, text, isteam)
	if(text == "/"..TicSys.cfg["Command"]) then
		net.Start("TicSys.openMenu")
		TicSys:setNetTickets()
		net.Send(ply)
	end
	if(string.sub(text,1,string.len("/"..TicSys.cfg["Fast Report Command"])) == "/"..TicSys.cfg["Fast Report Command"]) then
		local args = string.Explode(" ",string.sub(text,9))

		if #args > 2 then
			for i=3,#args do
				args[2] = args[2].." "..args[i]
			end
		end

		if #args < 2 || string.len(args[2]) < 2 || string.len(args[2]) > 20 then 
			TicSys:notify(ply, TicSys.lang["Command"].." /"..TicSys.cfg["Fast Report Command"].." "..string.lower(TicSys.lang["Name"]).." "..string.lower(TicSys.lang["Short Reason"]), 2)
			return ""
		end

		local ticket = {
			caller = {
				name = ply:Name(),
				steamid = ply:SteamID(),
				steamid64 = ply:SteamID64()
			},
			description = "",
			url = {},
			shortReason = string.Trim(args[2]),
		}

		for k,v in pairs(player.GetAll()) do
			if string.match(string.lower(v:Name()),string.lower(string.Trim(args[1]))) != nil then
				ticket.violator = {
					name = v:Name(),
					steamid = v:SteamID(),
					steamid64 = v:SteamID64(),
				}
			end
		end

		if ticket.violator then
			TicSys:newTicket(ply, ticket)
		else
			TicSys:notify(ply, TicSys.lang["ntf.Player Not Found"], 2)
		end

		return ""
	end
end)

hook.Add("PlayerInitialSpawn","TicSys.reloadCfg",function(ply)
	TicSys:reloadCfg(false, ply)
	ply:SetNWBool("isTicSysNotify", true)
end)