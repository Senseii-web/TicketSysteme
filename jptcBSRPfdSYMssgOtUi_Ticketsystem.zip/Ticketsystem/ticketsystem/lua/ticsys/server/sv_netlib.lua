util.AddNetworkString("TicSys.newTicket")
util.AddNetworkString("TicSys.takeTicket")
util.AddNetworkString("TicSys.closeTicket")
util.AddNetworkString("TicSys.deleteTicket")
util.AddNetworkString("TicSys.updateRating")
util.AddNetworkString("TicSys.updateSettings")
util.AddNetworkString("TicSys.resetSettings")
util.AddNetworkString("TicSys.contextMenuButton")
util.AddNetworkString("TicSys.toggleNotify")

net.Receive("TicSys.newTicket",function(len, ply)
	local ticket = net.ReadTable()

	ticket.caller = {name = ply:Name(), steamid = ply:SteamID(), steamid64 = ply:SteamID64()}
	ticket.violator = {name = "", steamid = "", steamid64 = "", otherinfo = ticket.otherinfo}
	if ticket.player then
		ticket.violator = {name = ticket.player:Name(), steamid = ticket.player:SteamID(), steamid64 = ticket.player:SteamID64(), otherinfo = ticket.otherinfo}
	end

	TicSys:newTicket(ply, ticket)
end)

net.Receive("TicSys.takeTicket",function(len, ply)
	if !TicSys:isOwner(ply) && !TicSys:isAdmin(ply) then return end
	local ticket = net.ReadTable()

	if ticket.verifier then 
		TicSys:notify(ply, TicSys.lang["ntf.Ticket Already Taken"], 0)
		return
	end
	if ticket.violator.steamid == ply:SteamID() then 
		TicSys:notify(ply, TicSys.lang["ntf.Can't Take Ticket Filed"], 0)
		return
	end
	if ticket.caller.steamid == ply:SteamID() then
		TicSys:notify(ply, TicSys.lang["ntf.Can't Take Ticket"], 0)
		return
	end

	local verifier = {
		name = ply:Name(),
		steamid = ply:SteamID(),
		steamid64 = ply:SteamID64(),
	}

	sql.Query("UPDATE ts_tickets SET verifier="..sql.SQLStr(util.TableToJSON(verifier))..", timeTaked="..sql.SQLStr(os.time()).." WHERE id="..sql.SQLStr(ticket.id).." AND verifier IS NULL")
	TicSys:updateTicket(ticket.id)

	TicSys:notify(ply, string.Replace(TicSys.lang["ntf.Take Ticket"],"%ID","#"..ticket.id), 0)
	TicSys:notify(player.GetBySteamID(ticket.caller.steamid), string.Replace(TicSys.lang["ntf.Ticket Reviewed"],"%ID","#"..ticket.id), 0)
end)

net.Receive("TicSys.closeTicket",function(len, ply)
	if !TicSys:isOwner(ply) && !TicSys:isAdmin(ply) then return end
	local ticket = net.ReadTable()

	sql.Query("UPDATE ts_tickets SET isSolved=1, timeClosed="..sql.SQLStr(os.time()).." WHERE id="..sql.SQLStr(ticket.id))
	TicSys:updateTicket(ticket.id)

	TicSys:notify(ply, string.Replace(TicSys.lang["ntf.Closed Ticket"],"%ID","#"..ticket.id), 0)
	TicSys:notify(player.GetBySteamID(ticket.caller.steamid), string.Replace(TicSys.lang["ntf.Ticket Resolved"],"%ID","#"..ticket.id), 0)
end)

net.Receive("TicSys.deleteTicket",function(len, ply)
	if !TicSys:isOwner(ply) then return end
	local ticket = net.ReadTable()

	sql.Query("DELETE FROM ts_tickets WHERE id="..sql.SQLStr(ticket.id))

	TicSys:notify(ply, string.Replace(TicSys.lang["ntf.Deleted Ticket"],"%ID","#"..ticket.id), 0)
end)

net.Receive("TicSys.updateRating",function(len, ply)
	local ticket = net.ReadTable()
	if ticket.caller.steamid != ply:SteamID() then return end

	sql.Query("UPDATE ts_tickets SET rating="..sql.SQLStr(ticket.rating).." WHERE id="..sql.SQLStr(ticket.id).." AND rating=-1")

	TicSys:updateTicket(ticket.id)

	TicSys:notify(player.GetBySteamID(ticket.verifier.steamid), string.Replace(TicSys.lang["ntf.Ticket Rating"],"%ID","#"..ticket.id), 0)
	TicSys:notify(player.GetBySteamID(ticket.caller.steamid), string.Replace(TicSys.lang["ntf.Successfully Rating"],"%ID","#"..ticket.id), 0)
end)

net.Receive("TicSys.updateSettings",function(len, ply)
	if !TicSys:isOwner(ply) then return end
	local newSettings = net.ReadTable()

	if newSettings.config.Command != TicSys.cfg.Command then
		TicSys:changeCommand(newSettings.config.Command)
	end

	TicSys.cfg = newSettings.config
	TicSys.lang = newSettings.language

	TicSys:reloadCfg(true)

	if file.Exists("ticketsystem/settings.txt", "DATA") then
		file.Write("ticketsystem/settings.txt", util.TableToJSON(newSettings))
	end

	TicSys:notify(ply, "Settings have been saved and updated!", 1)
end)

net.Receive("TicSys.resetSettings",function(len, ply)
	if !TicSys:isOwner(ply) then return end

	TicSys:changeCommand(TicSys.defaultSettings.config.Command)

	TicSys.cfg = TicSys.defaultSettings.config
	TicSys.lang = TicSys.defaultSettings.language

	TicSys:reloadCfg(true)

	if file.Exists("ticketsystem/settings.txt", "DATA") then
		file.Write("ticketsystem/settings.txt", util.TableToJSON(TicSys.defaultSettings))
	end

	TicSys:notify(ply, "Settings have been saved and updated!", 1)
end)

net.Receive("TicSys.contextMenuButton",function(len, ply)
	net.Start("TicSys.openMenu")
	TicSys:setNetTickets()
	net.Send(ply)
end)

net.Receive("TicSys.toggleNotify",function(len, ply)
	if ply:GetNWBool("isTicSysNotify") then
		ply:SetNWBool("isTicSysNotify", false)
	else
		ply:SetNWBool("isTicSysNotify", true)
	end
end)