surface.CreateFont( "TicSys.20", {
	font = "Open Sans",
	size = 20,
	weight = 500,
	antialias = true,
	extended = true,
})

surface.CreateFont( "TicSys.17Bold", {
	font = "Open Sans",
	size = 17,
	weight = 700,
	antialias = true,
	extended = true,
})

surface.CreateFont( "TicSys.15", {
	font = "Open Sans",
	size = 15,
	weight = 100,
	antialias = true,
	extended = true,
})

surface.CreateFont( "TicSys.25", {
	font = "Open Sans",
	size = 25,
	weight = 500,
	antialias = true,
	extended = true,
})

surface.CreateFont( "TicSys.31", {
	font = "Calibri Light",
	size = 31,
	weight = 100,
	antialias = true,
	extended = true,
	italic = false,
})

surface.CreateFont( "TicSys.20Bold", {
	font = "Open Sans",
	size = 20,
	weight = 700,
	antialias = true,
	extended = true,
})