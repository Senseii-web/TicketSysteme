function TicSys:checkFilters(v, filters)
	local ply_name, ply_steamid
	if IsValid(filters.player) then
		ply_name = string.lower(filters.player:Name())
		ply_steamid = string.lower(filters.player:SteamID())
	elseif filters.otherInfoPlayer then
		ply_name = string.lower(filters.otherInfoPlayer)
		ply_steamid = string.lower(filters.otherInfoPlayer)
	end
	if v.violator.otherinfo == nil then v.violator.otherinfo = "" end

	if ply_name != nil && ply_steamid != nil then
		if filters.type then
			if filters.type == 1 then
				if ply_name != string.lower(v.caller.name) && ply_steamid != string.lower(v.caller.steamid) then return false end
			end
			if filters.type == 2 then
				if ply_name != string.lower(v.violator.name) && ply_steamid != string.lower(v.violator.steamid) && ply_name != string.lower(v.violator.otherinfo) && ply_steamid != string.lower(v.violator.otherinfo) then return false end
			end
			if filters.type == 3 then
				if v.verifier then
					if ply_name != string.lower(v.verifier.name) && ply_steamid != string.lower(v.verifier.steamid) then return false end
				else
					return false
				end
			end
		else
			if ply_name != string.lower(v.caller.name) && ply_steamid != string.lower(v.caller.steamid) && ply_name != string.lower(v.violator.name) && ply_steamid != string.lower(v.violator.steamid) && ply_name != string.lower(v.violator.otherinfo) && ply_steamid != string.lower(v.violator.otherinfo) && (!v.verifier || (ply_name != string.lower(v.verifier.name) || ply_steamid != string.lower(v.verifier.steamid))) then return false end
		end
	end
	if filters.reason && filters.reason != TicSys.lang["All"] && filters.reason != v.shortReason then return false end
	if filters.time then
		local to = filters.time + 86399

		if tonumber(v.timeOpen) < filters.time || tonumber(v.timeOpen) > to then
			return false
		end
		if v.timeClosed != "NULL" then
			if tonumber(v.timeClosed) < filters.time || tonumber(v.timeClosed) > to then
				return false
			end
		end
	end
	return true
end

function TicSys:getSendTickets(steamid)
	local count = 0
	for k,v in pairs(TicSys.tickets) do
		if v.caller.steamid == steamid then
			count = count + 1
		end
	end
	return count
end

function TicSys:getSolvedTickets(steamid)
	local count = 0
	for k,v in pairs(TicSys.tickets) do
		if v.isSolved == "1" && v.verifier.steamid == steamid then
			count = count + 1
		end
	end
	return count
end

function TicSys:getReputation(steamid)
	local rating = 0
	local count = 0
	for k,v in pairs(TicSys.tickets) do
		if v.isSolved == "1" && v.verifier.steamid == steamid && v.rating != "-1" then
			rating = rating + v.rating
			count = count + 1
		end
	end
	local averageRating = math.Truncate(rating/count, 1)
	if averageRating > 0 then
		return averageRating
	else
		return 0
	end
end

function TicSys:getRank(steamid)
	if TicSys:getSolvedTickets(steamid) < 10 then return false end
	local rating = TicSys:getReputation(steamid)
	for k,v in pairs(TicSys.cfg["Ranks"]) do
		if rating > v.min && rating <= v.max then
			return v
		end 
	end
	return false
end

function TicSys:updatePanels()
	for k,v in pairs(self.panels) do
		if !IsValid(v) then continue end

		if v.filters then
			v:loadTickets()
		else
			v:Clear()
			if v.ticket then
				for c,d in pairs(TicSys.tickets) do
					if d.id == v.ticket.id then
						v.ticket = d
					end
				end
			end
			v:loadPanel()
		end
	end
end