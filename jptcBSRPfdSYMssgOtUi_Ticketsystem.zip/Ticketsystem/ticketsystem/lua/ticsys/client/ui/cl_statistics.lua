local PANEL = {}
function PANEL:Init()
	self:SetPos(250,0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())

	self:loadPanel()
end

function PANEL:loadPanel()
	self.filters = {}
	self.filters.type = 1
	
	self:sortPlayersTickets()
	self:sortRating()
	self:loadRatingList()

	self:TicSysTitle()
	self:boxSelectType()
end

function PANEL:boxSelectType()
	local box = self:TicSysBox(89, TicSys.lang["Select Type"], 10)

	local selectType = vgui.Create( "DComboBox",box )
	selectType:Dock(FILL)
	selectType:DockMargin(15,30,10,25)
	selectType:SetValue( TicSys.lang["stats.Average Rating"] )
	selectType:SetSortItems(false)
	selectType.OnSelect = function( panel, value, data )
		self.filters.type = value
	end
	selectType:AddChoice( TicSys.lang["stats.Average Rating"] )
	selectType:AddChoice( TicSys.lang["stats.Average Time"] )
	selectType:AddChoice( TicSys.lang["Count Solved Tickets"] )
	selectType:AddChoice( TicSys.lang["Count Send Tickets"] )

	local load = box:TicSysButton(" "..TicSys.lang["Load Statistics"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,30,15,25},true)
	load.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,130))
	end
	load.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		if self.filters.type == 1 then
			self:sortRating()
		elseif self.filters.type == 2 then
			self:sortAverageTime()
		elseif self.filters.type == 3 then
			self:sortCountSolved()
		elseif self.filters.type == 4 then
			self:sortCountSend()
		end
		self:loadRatingList()
	end
	load:TicSysHoverEffect()
end

function PANEL:loadRatingList()
	if IsValid(self.ratingPanel) then self.ratingPanel:Remove() end

	self.ratingPanel = vgui.Create("DPanel",self)
	self.ratingPanel:Dock(FILL)
	self.ratingPanel:DockMargin(15,5,15,14)
	self.ratingPanel:SetDrawBackground(false)

	local category = vgui.Create("DPanel",self.ratingPanel)
	category:Dock(TOP)
	category:SetTall(24)
	category.Paint = function(self)
		draw.RoundedBox(3, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111,255))
	end
	category:TicSysLabel(TicSys.lang["ctg.position"], "TicSys.17Bold", false, false, 110, 24, Color(255,255,255), LEFT, {10,0,0,0}, false)
	category:TicSysLabel(TicSys.lang["ctg.player"], "TicSys.17Bold", false, false, 235, 24, Color(255,255,255), LEFT, {10,0,0,0}, false)
	category:TicSysLabel(TicSys.lang["ctg.rating"], "TicSys.17Bold", false, false, 80, 24, Color(255,255,255), LEFT, {35,0,0,0}, false,5)

	local scroll = self.ratingPanel:TicSysScroll({0,5,0,0})
	for i=1,TicSys.cfg["Statistics TOP ?"] do
		local item = self.sortedTbl[i]
		if item == nil then continue end

		local positionColor = Color(77,168,148)
		local bgColor = Color(0,0,0,0)
		local isBorder = false
		if i == 1 then
			positionColor = Color(67,223,221)
			bgColor = Color(0,0,0,65)
			isBorder = true
		elseif i == 2 then
			positionColor = Color(225,221,67)
			bgColor = Color(0,0,0,65)
			isBorder = true
		elseif i == 3 then
			positionColor = Color(223,152,67)
			bgColor = Color(0,0,0,65)
			isBorder = true
		end

		local line = vgui.Create("DPanel",scroll)
		line:Dock(TOP)
		line:DockMargin(0,0,0,5)
		line:SetTall(36)
		line.Paint = function(self)
			draw.RoundedBox(3, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111,255))

			if isBorder then
				draw.RoundedBox(3, 1, 1, self:GetWide()-2, self:GetTall()-2, positionColor)
				draw.RoundedBox(3, 2, 2, self:GetWide()-4, self:GetTall()-4, Color(62,82,111,255))
			end
		end

		line:TicSysLabel("№"..i, "TicSys.17Bold", false, false, 60, 36, Color(255,255,255), LEFT, {10,0,0,0}, false)

		line:TicSysAvatar(true, false, false, 20, 20, false, item.ply.steamid64, LEFT, {60,8,0,8})
		line:TicSysLabel(item.ply.name, "TicSys.17Bold", false, false, 210, 36, Color(255,255,255), LEFT, {5,0,0,0}, false)

		line:TicSysLabel(item.rt, "TicSys.17Bold", false, false, 80, 36, Color(255,255,255), LEFT, {35,0,0,0}, false,5)

		local openProfile = line:TicSysButton("  "..TicSys.lang["Open Profile"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
		openProfile.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), positionColor)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), bgColor)
		end
		openProfile.DoClick = function()
			surface.PlaySound( "buttons/button15.wav" )
			TicSys:openProfile(false, item.ply.steamid, item.ply)
		end
		openProfile:TicSysHoverEffect()
	end
end

function PANEL:sortPlayersTickets()
	self.players = {}
	for k,v in pairs(TicSys.tickets) do
		if !self.players[v.caller.steamid] then
			self.players[v.caller.steamid] = v.caller
		elseif v.verifier && !self.players[v.verifier.steamid] then
			self.players[v.verifier.steamid] = v.verifier
		end
	end
end

function PANEL:sortRating()
	self.sortedTbl = {}

	for k,v in pairs(self.players) do
		local rating = TicSys:getReputation(k)
		table.insert(self.sortedTbl, {ply = v, rt = rating})
	end

	table.SortByMember(self.sortedTbl, "rt")
end

function PANEL:sortCountSolved()
	self.sortedTbl = {}

	for k,v in pairs(self.players) do
		local count = 0
		for c,d in pairs(TicSys.tickets) do
			if d.isSolved == "1" && d.verifier.steamid == k then
				count = count + 1
			end
		end
		table.insert(self.sortedTbl, {ply = v, rt = count})
	end

	table.SortByMember(self.sortedTbl, "rt")
end

function PANEL:sortCountSend()
	self.sortedTbl = {}

	for k,v in pairs(self.players) do
		local count = 0
		for c,d in pairs(TicSys.tickets) do
			if d.caller.steamid == k then
				count = count + 1
			end
		end
		table.insert(self.sortedTbl, {ply = v, rt = count})
	end

	table.SortByMember(self.sortedTbl, "rt")
end

function PANEL:sortAverageTime()
	self.sortedTbl = {}

	for k,v in pairs(self.players) do
		local count = 0
		local time = 0
		for c,d in pairs(TicSys.tickets) do
			if d.isSolved == "1" && d.verifier.steamid == k then
				time = time + (tonumber(d.timeClosed) - tonumber(d.timeTaked))
				count = count + 1
			end
		end
		local averageTime = math.ceil(time / count)
		if tostring(averageTime) == "nan" then continue end
		table.insert(self.sortedTbl, {ply = v, rt = averageTime})
	end

	table.SortByMember(self.sortedTbl, "rt", true)
end

vgui.Register( "TicSys.statistics", PANEL, "Panel" )