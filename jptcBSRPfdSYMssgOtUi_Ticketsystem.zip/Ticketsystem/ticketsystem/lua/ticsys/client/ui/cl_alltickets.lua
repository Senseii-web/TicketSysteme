local PANEL = {}
function PANEL:Init()
	self:SetPos(250,0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())

	self:loadPanel()

	table.insert(TicSys.panels, self)
end

function PANEL:loadPanel()
	self.filters = {}

	local title = self:TicSysTitle()
	self:loadTickets()

	self.boxFilters = self:TicSysBox(0, TicSys.lang["Filters"], 0)
	self.boxFilters:TicSysFilters()

	self:TicSysCategories({5,5,5,5}, true, true, true, true, false)

	local toggleFilter = title:TicSysButton(" "..TicSys.lang["Filters"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,5,5,5},true)
	toggleFilter.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	toggleFilter.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		self.boxFilters:TicSysToggleFilters()
	end
	toggleFilter:TicSysHoverEffect()
end

function PANEL:loadTickets()
	if IsValid(self.boxTickets)	then self.boxTickets:Remove() end

	self.boxTickets = self:TicSysScroll({5,0,5,5})

	for k,v in pairs(table.Reverse(TicSys.tickets)) do
		if v.isSolved == "0" then
			if !TicSys:checkFilters(v, self.filters) then
				continue
			end
			self.boxTickets:TicSysLine(v, true, true, true, true, false)
		end
	end
end

vgui.Register( "TicSys.allTickets", PANEL, "Panel" )