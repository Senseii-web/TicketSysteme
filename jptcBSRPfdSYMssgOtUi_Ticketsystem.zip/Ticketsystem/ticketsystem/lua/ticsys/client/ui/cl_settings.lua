local PANEL = {}
function PANEL:Init()
	self:SetPos(250,0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())

	self:loadPanel()
end

function PANEL:loadPanel()
	self.settings = {
		config = table.Copy(TicSys.cfg),
		language = table.Copy(TicSys.lang),
	}

	local title = self:TicSysTitle()
	local save = title:TicSysButton(" "..TicSys.lang["Save"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,5,5,5},true)
	save.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	save.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		net.Start("TicSys.updateSettings")
		net.WriteTable(self.settings)
		net.SendToServer()
	end
	save:TicSysHoverEffect()

	local resetAll = title:TicSysButton(" "..TicSys.lang["Reset All"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,5,5,5},true)
	resetAll.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
	end
	resetAll.DoClick = function()
		TicSys.menu.frame.settingsPanel = self

		surface.PlaySound( "buttons/button15.wav" )
		net.Start("TicSys.resetSettings")
		net.SendToServer()
	end
	resetAll:TicSysHoverEffect()

	self.scroll = self:TicSysScroll({5,5,5,5})
	self:loadConfig()
	self:loadLanguage()
end

function PANEL:loadConfig()
	local title = self.scroll:TicSysLabel("Config","TicSys.20",false,false,false,33,Color(255,255,255),TOP,{0,0,0,5},true,5)
	title.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(199,142,56))
	end

	for k,v in pairs(TicSys.cfg) do
		local line = vgui.Create("DPanel", self.scroll)
		line:Dock(TOP)
		line:DockMargin(0,0,0,5)
		line:SetTall(30)
		line.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))
		end

		line:TicSysLabel(k,"TicSys.20",false,false,230,false,Color(255,255,255),LEFT,{5,0,0,0},true)

		if isnumber(v) || isstring(v) then
			local textEntry = vgui.Create( "DTextEntry", line )
			textEntry:Dock(FILL)
			textEntry:DockMargin(10,3,3,3)
			textEntry:SetText(v)
			textEntry.OnChange = function()
				self.settings.config[k] = tonumber(textEntry:GetValue()) || textEntry:GetValue()
			end
			if isnumber(v) then textEntry:SetNumeric(true) end

			local resetValue = line:TicSysButton("↺","TicSys.20Bold",false,false,false,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
			resetValue.Paint = function(self)
				draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
			end
			resetValue.DoClick = function()
				surface.PlaySound( "buttons/button15.wav" )
				self.settings.config[k] = TicSys.defaultSettings.config[k]
				textEntry:SetText(TicSys.defaultSettings.config[k])
			end
			resetValue:TicSysHoverEffect()
			resetValue:SetTooltip("Reset")
		elseif istable(v) then
			line:SetTall(3)

			local entryBox = vgui.Create("DPanel", line)
			entryBox:Dock(FILL)
			entryBox:DockMargin(10,0,0,3)
			entryBox.Paint = function(self)
				draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))
			end

			if !istable(v[1]) then
				local newValue = vgui.Create( "DTextEntry", entryBox )
				newValue:Dock(TOP)
				newValue:DockMargin(0,3,3,0)
				newValue:SetTall(25)
				newValue:SetPlaceholderText( "Enter new value" )
				newValue.OnEnter = function()
					if string.len(newValue:GetValue()) < 1 then return end
					surface.PlaySound( "buttons/button15.wav" )
					local textEntry = self:itemLine(line, entryBox, k, newValue:GetValue())
					line:SetTall(line:GetTall()+textEntry:GetTall()+3)
					newValue:SetText("")

					table.insert(self.settings.config[k], textEntry:GetValue())
				end

				local add = newValue:TicSysButton("+","TicSys.20Bold",false,false,20,false,Color(255,255,255),RIGHT,{2,2,2,2},true)
				add.Paint = function(self)
					draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
				end
				add.DoClick = function()
					newValue.OnEnter()
				end
				add:TicSysHoverEffect()

				line:SetTall(line:GetTall()+28)
			end

			for c,d in pairs(v) do
				if istable(d) then
					local itemLine = vgui.Create("DPanel", entryBox)
					itemLine:Dock(TOP)
					itemLine:DockMargin(0,3,0,0)
					itemLine:SetTall(25)
					itemLine.Paint = function(self)
						draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))
					end

					itemLine:TicSysLabel("Rating: "..d.min.."-"..d.max,"TicSys.20",false,false,false,false,Color(255,255,255),LEFT,{0,0,5,0},true)

					local textEntry = vgui.Create( "DTextEntry", itemLine)
					textEntry:Dock(FILL)
					textEntry:SetText( d.rank )
					textEntry.OnChange = function()
						self.settings.config[k][c].rank = textEntry:GetValue()
					end

					local resetValue = itemLine:TicSysButton("↺","TicSys.20Bold",false,false,false,false,Color(255,255,255),RIGHT,{0,2,4,2},true)
					resetValue.Paint = function(self)
						draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
					end
					resetValue.DoClick = function()
						surface.PlaySound( "buttons/button15.wav" )

						self.settings.config[k][c].rank = TicSys.defaultSettings.config[k][c].rank
						self.settings.config[k][c].color = TicSys.defaultSettings.config[k][c].color

						textEntry:SetText(self.settings.config[k][c].rank)
					end
					resetValue:TicSysHoverEffect()
					resetValue:SetTooltip("Reset")

					local colorMixer = itemLine:TicSysButton("","TicSys.20",false,false,25,25,Color(0,0,0),RIGHT,{3,2,4,2})
					colorMixer.Paint = function()
						draw.RoundedBox(6, 0, 0, colorMixer:GetWide(), colorMixer:GetTall(), self.settings.config[k][c].color)
					end
					colorMixer.DoClick = function()
						self:colorMixer(k, c)
					end

					line:SetTall(line:GetTall()+28)
				else
					local textEntry = self:itemLine(line, entryBox, k, d)
					line:SetTall(line:GetTall()+28)
				end
			end
		end
	end
end

function PANEL:loadLanguage()
	local title = self.scroll:TicSysLabel("Language","TicSys.20",false,false,false,33,Color(255,255,255),TOP,{0,0,0,5},true,5)
	title.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(199,142,56))
	end

	for k,v in pairs(TicSys.lang) do
		local line = vgui.Create("DPanel", self.scroll)
		line:Dock(TOP)
		line:DockMargin(0,0,0,5)
		line:SetTall(30)
		line.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))
		end

		line:TicSysLabel(k,"TicSys.20",false,false,230,false,Color(255,255,255),LEFT,{5,0,0,0},true)

		local textEntry = vgui.Create( "DTextEntry", line )
		textEntry:Dock(FILL)
		textEntry:DockMargin(10,3,3,3)
		textEntry:SetText( v )
		textEntry.OnChange = function()
			self.settings.language[k] = textEntry:GetValue()
		end

		local resetValue = line:TicSysButton("↺","TicSys.20Bold",false,false,false,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
		resetValue.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
		end
		resetValue.DoClick = function()
			surface.PlaySound( "buttons/button15.wav" )
			self.settings.language[k] = TicSys.defaultSettings.language[k]
			textEntry:SetText(TicSys.defaultSettings.language[k])
		end
		resetValue:TicSysHoverEffect()
		resetValue:SetTooltip("Reset")
	end
end

function PANEL:itemLine(line, entryBox, k, d)
	local textEntry = vgui.Create( "DTextEntry", entryBox)
	textEntry:Dock(BOTTOM)
	textEntry:DockMargin(0,3,3,0)
	textEntry:SetText( d )
	textEntry:SetTall(25)
	textEntry.OnChange = function(self)
		if self:GetText() != d then 
			self:SetText(d)
		end
	end

	local delete = textEntry:TicSysButton("X","TicSys.17Bold",false,false,20,false,Color(255,255,255),RIGHT,{2,2,2,2},true)
	delete.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
	end
	delete.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		textEntry:Remove()
		line:SetTall(line:GetTall()-textEntry:GetTall()-3)

		table.RemoveByValue(self.settings.config[k],d)
	end
	delete:TicSysHoverEffect()

	return textEntry
end

function PANEL:colorMixer(k, c)
	local frame = vgui.Create( "DFrame" )
	frame:SetSize( 300, 200 )
	frame:SetPos( ScrW()/2-frame:GetWide()/2, ScrH()/2-frame:GetTall()/2 )
	frame:SetTitle( "Color Mixer" )
	frame:SetDraggable( false )
	frame:MakePopup()
	frame.Think = function(self) self:MoveToFront() end 

	local mixer = vgui.Create( "DColorMixer", frame )
	mixer:Dock( FILL )
	mixer:SetPalette( true )
	mixer:SetAlphaBar( true )
	mixer:SetWangs( true )
	mixer:SetColor( Color( 30, 100, 160 ) )
	mixer.ValueChanged = function()
		if !IsValid(self) then return end
		self.settings.config[k][c].color = mixer:GetColor()
	end
end

vgui.Register( "TicSys.settings", PANEL, "Panel" )