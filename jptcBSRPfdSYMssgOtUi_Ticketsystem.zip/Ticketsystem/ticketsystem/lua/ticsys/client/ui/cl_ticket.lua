local ticket
function TicSys:openTicket(v)
	ticket = v
	self.menu.frame:Add("TicSys.ticket")
end

local PANEL = {}
function PANEL:Init()
	self:SetPos(self:GetParent():GetWide(),0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())
	self.Paint = function(self)
		draw.RoundedBox(8, 0, 0, self:GetWide(), self:GetTall(), Color(236,236,236))
	end
	self:SetZPos(1)
	self:MoveToFront()

	self.ticket = ticket

	self:loadPanel()
	self:MoveTo(250,0,0.4)

	table.insert(TicSys.panels, self)
end

function PANEL:loadPanel()
	if self.ticket == nil then self:Remove() return end
	local title = self:TicSysTitle(TicSys.lang["Information Ticket"].." #"..self.ticket.id.." ", "materials/ticsys/alltickets.png")

	self:loadTopPanel()
	self:loadBoxPlayers()
	self:loadBoxDescription()
	self:loadBoxFiles()
	self:loadAdminBtns()

	local closeButton = self:TicSysButton("","TicSys.20",self:GetWide()-51,5,40,40,Color(255,255,255))
	closeButton.Paint = function(self)
		surface.SetMaterial( Material("materials/ticsys/close.png") )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect(5, 5, 30, 30 )
	end
	closeButton.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		self:MoveTo(self:GetParent():GetWide(),0,0.4,0,-1,function()
			self:Remove()
		end)
	end

	if self.ticket.isSolved == "1" then
		local solvedLabel = title:TicSysLabel("  "..TicSys.lang["Solved"].."  ","TicSys.17Bold",false,false,false,26,Color(255,255,255),LEFT,{5,9,0,9},true,5)
		solvedLabel.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
		end
	else
		local solvedLabel = title:TicSysLabel("  "..TicSys.lang["Not Solved"].."  ","TicSys.17Bold",false,false,false,25,Color(255,255,255),LEFT,{5,9,0,9},true,5)
		solvedLabel.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
		end
	end
end

function PANEL:loadTopPanel()
	local topPanel = vgui.Create("DPanel",self)
	topPanel:Dock(TOP)
	topPanel:DockMargin(15,10,15,5)
	topPanel:SetTall(26)
	topPanel:SetDrawBackground(false)

	local timeOpen = topPanel:TicSysLabel("  "..TicSys.lang["Opened"]..": "..os.date("%H:%M - "..TicSys.cfg["Format Date"],self.ticket.timeOpen).."  ","TicSys.17Bold",false,false,false,false,Color(255,255,255),LEFT,{0,0,10,0},true)
	timeOpen.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,130))
	end
	if self.ticket.timeClosed != "NULL" then
		local timeClosed = topPanel:TicSysLabel("  "..TicSys.lang["Closed"]..": "..os.date("%H:%M - "..TicSys.cfg["Format Date"],self.ticket.timeClosed).."  ","TicSys.17Bold",false,false,false,false,Color(255,255,255),LEFT,{0,0,10,0},true)
		timeClosed.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,130))
		end
	end

	if self.ticket.isSolved == "1" && (tonumber(self.ticket.rating) != -1 || (tonumber(self.ticket.rating) == -1 && self.ticket.caller.steamid == LocalPlayer():SteamID())) then
		local ratingPanel = vgui.Create("DPanel",topPanel)
		ratingPanel:Dock(RIGHT)
		ratingPanel:SetTall(26)
		ratingPanel:SetWide(111)
		ratingPanel.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))

			for i=0,4 do
				surface.SetMaterial( Material("materials/ticsys/star.png") )
				surface.SetDrawColor( 225,221,67,100 )
				surface.DrawTexturedRect(4+i*21, 4, 18, 18 )
			end
		end

		local rating = 0
		if tonumber(self.ticket.rating) != -1 then rating = self.ticket.rating end

		local stars = vgui.Create("DPanel",ratingPanel)
		stars:SetPos(4,0)
		stars:SetSize(102,ratingPanel:GetTall())
		stars.Paint = function(self)
			for i=0,4 do
				surface.SetMaterial( Material("materials/ticsys/star.png") )
				surface.SetDrawColor( 225,221,67 )
				surface.DrawTexturedRect(i*21, 4, 18, 18 )
			end
		end
		stars.Think = function(self)
			self:SetWide(102*(100*rating/5)/100)
		end

		if tonumber(self.ticket.rating) == -1 && self.ticket.caller.steamid == LocalPlayer():SteamID() then
			local numSlider = vgui.Create( "DNumSlider", ratingPanel )
			numSlider:SetPos( 4, 0 )
			numSlider:SetSize( 102, 26 )
			numSlider:SetMinMax(0,5)
			numSlider:SetDecimals(1)
			numSlider.Slider.Paint = function() end
			numSlider.Slider.Knob.Paint = function() end
			numSlider.Slider.Knob:SetCursor("arrow")
			numSlider.TextArea:Dock(NODOCK)
			numSlider.TextArea:SetSize(0,0)
			numSlider.Label:Dock(NODOCK)
			numSlider.Label:SetSize(0,0)
			numSlider.OnValueChanged = function(value)
				rating = numSlider:GetValue()
			end

			local accept = ratingPanel:TicSysButton(TicSys.lang["Accept"],"TicSys.17Bold",false,false,false,false,Color(255,255,255),RIGHT,{0,3,3,3},true)
			accept.Paint = function(self)
				draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
			end
			accept.DoClick = function()
				surface.PlaySound( "buttons/button15.wav" )

				self.ticket.rating = numSlider:GetValue()

				net.Start("TicSys.updateRating")
				net.WriteTable(self.ticket)
				net.SendToServer()
			end
			accept:TicSysHoverEffect()

			ratingPanel:SetWide(ratingPanel:GetWide()+accept:GetWide()+3)
		end
	end
end

function PANEL:loadAdminBtns()
	local adminBtns = vgui.Create("DPanel",self)
	adminBtns:Dock(BOTTOM)
	adminBtns:DockMargin(15,0,15,15)
	adminBtns:SetTall(35)
	adminBtns:SetDrawBackground(false)

	if self.ticket.isSolved == "0" && (TicSys:isOwner(LocalPlayer()) || TicSys:isAdmin(LocalPlayer())) then
		if !self.ticket.verifier then
			local takeTicket = adminBtns:TicSysButton("  "..TicSys.lang["Take Ticket"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{10,0,0,0},true)
			takeTicket.Paint = function(self)
				draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
			end
			takeTicket.DoClick = function()
				surface.PlaySound( "buttons/button15.wav" )
				net.Start("TicSys.takeTicket")
				net.WriteTable(self.ticket)
				net.SendToServer()
			end
			takeTicket:TicSysHoverEffect()
		end
		if self.ticket.verifier && (LocalPlayer():SteamID() == self.ticket.verifier.steamid || TicSys:isOwner(LocalPlayer())) then
			local closeTicket = adminBtns:TicSysButton("  "..TicSys.lang["Close Ticket"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{10,0,0,0},true)
			closeTicket.Paint = function(self)
				draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
			end
			closeTicket.DoClick = function()
				surface.PlaySound( "buttons/button15.wav" )
				net.Start("TicSys.closeTicket")
				net.WriteTable(self.ticket)
				net.SendToServer()
			end
			closeTicket:TicSysHoverEffect()
		end
	end

	if TicSys:isOwner(LocalPlayer()) then
		local deleteTicket = adminBtns:TicSysButton("  "..TicSys.lang["Delete Ticket"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{10,0,0,0},true)
		deleteTicket.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
		end
		deleteTicket.DoClick = function()
			surface.PlaySound( "buttons/button15.wav" )
			net.Start("TicSys.deleteTicket")
			net.WriteTable(self.ticket)
			net.SendToServer()

			for k,v in pairs(TicSys.tickets) do
				if v.id == self.ticket.id then
					TicSys.tickets[k] = nil
				end
			end
			self:Remove()
			TicSys:updatePanels()
		end
		deleteTicket:TicSysHoverEffect()
	end
end

function PANEL:loadBoxPlayers()
	local box = self:TicSysBox(132, TicSys.lang["Players"], 5)

	self:addPlayer(box, player.GetBySteamID(self.ticket.caller.steamid), self.ticket.caller, 30, TicSys.lang["ctg.caller"], true)
	self:addPlayer(box, player.GetBySteamID(self.ticket.violator.steamid), self.ticket.violator, 5, TicSys.lang["ctg.violator"], true)
	if self.ticket.verifier then
		box:SetTall(173)
		self:addPlayer(box, player.GetBySteamID(self.ticket.verifier.steamid), self.ticket.verifier, 5, TicSys.lang["ctg.verifier"], false)
	end
end

function PANEL:loadBoxDescription()
	local box = self:TicSysBox(212, TicSys.lang["Description"], 5)

	local shortReason = vgui.Create( "DTextEntry", box )
	shortReason:SetTall( 30 )
	shortReason:Dock(TOP)
	shortReason:DockMargin(15,30,15,0)
	shortReason:SetText( self.ticket.shortReason )
	shortReason.OnChange = function()
		if shortReason:GetText() != self.ticket.shortReason then 
			shortReason:SetText(self.ticket.shortReason)
		end
	end

	local description = vgui.Create( "DTextEntry", box )
	description:SetTall( 120 )
	description:Dock(TOP)
	description:DockMargin(15,5,15,0)
	description:SetMultiline(true)
	description:SetText( self.ticket.description )
	description:SetVerticalScrollbarEnabled(true)
	description.OnChange = function()
		if description:GetText() != self.ticket.description then 
			description:SetText(self.ticket.description)
		end
	end
end

function PANEL:loadBoxFiles()
	local box = self:TicSysBox(175, TicSys.lang["Files"], 5)

	local listFiles = vgui.Create( "DListView", box )
	listFiles:SetTall(box:GetTall()-56)
	listFiles:Dock( TOP )
	listFiles:DockMargin(15,30,15,0)
	listFiles:SetMultiSelect( false )
	listFiles:AddColumn( TicSys.lang["URL"] )
	for k,v in pairs(self.ticket.url) do
		listFiles:AddLine(v)
	end
	listFiles.OnRowSelected = function( panel, rowIndex, row )
		if string.sub(row:GetValue(1), 1, 8) != "https://" then
			gui.OpenURL("https://"..row:GetValue(1))
		else
			gui.OpenURL(row:GetValue(1))
		end
	end
end

function PANEL:addPlayer(parent, ply, tbl, docktop, group, isCommands)
	local line = vgui.Create("DPanel",parent)
	line:Dock(TOP)
	line:DockMargin(15,docktop,15,0)
	line:SetTall(36)
	line.Paint = function(self)
		draw.RoundedBox(3, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111,255))
	end

	line:TicSysLabel(group, "TicSys.17Bold", false, false, 120, 36, Color(255,255,255), LEFT, {10,0,0,0})
	if tbl.name != "" && tbl.steamid != "" then
		line:TicSysAvatar(true, false, false, 20, 20, false, tbl.steamid64, LEFT, {5,8,0,8})
		line:TicSysLabel(tbl.name, "TicSys.17Bold", false, false, 110, 36, Color(255,255,255), LEFT, {5,0,0,0})
		line:TicSysLabel(tbl.steamid, "TicSys.17Bold", false, false, 135, 36, Color(255,255,255), LEFT, {5,0,0,0})

		local openProfile = line:TicSysButton("  "..TicSys.lang["Open Profile"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
		openProfile.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
		end
		openProfile.DoClick = function()
			surface.PlaySound( "buttons/button15.wav" )
			TicSys:openProfile(false, tbl.steamid, tbl)
		end
		openProfile:TicSysHoverEffect()

		if isCommands && (TicSys:isAdmin(LocalPlayer()) || TicSys:isOwner(LocalPlayer())) then
			local commandList = {
				{icon = "arrow_right.png", command = "goto \""..tbl.name.."\"", tooltip = "Goto"},
				{icon = "arrow_left.png", command = "bring \""..tbl.name.."\"", tooltip = "Bring"},
				{icon = "arrow_redo.png", command = "return \""..tbl.name.."\"", tooltip = "Return"},
			}

			for k,v in pairs(commandList) do
				local button = line:TicSysButton("","TicSys.20Bold",false,false,24,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
				button.Paint = function(self)
					draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(236,236,236))
				end
				button.DoClick = function()
					surface.PlaySound( "buttons/button15.wav" )
					if ulx || serverguard then
						LocalPlayer():ConCommand("say !"..v.command)
					else
						LocalPlayer():ConCommand("fadmin "..v.command)
					end
				end
				button:SetImage("icon16/"..v.icon)
				button:SetTooltip(v.tooltip)
				button:TicSysHoverEffect()
			end
		end
	else
		line:TicSysLabel(tbl.otherinfo, "TicSys.17Bold", false, false, 550, 36, Color(255,255,255), LEFT, {5,0,0,0})
	end
end

vgui.Register( "TicSys.ticket", PANEL, "Panel" )