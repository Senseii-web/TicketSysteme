local profilePlayer
function TicSys:openProfile(user, steamid, tbl)
	local ply = user
	if steamid && player.GetBySteamID(steamid) then ply = player.GetBySteamID(steamid) end

	if IsValid(ply) then
		profilePlayer = {
			name = ply:Name(),
			group = ply:GetUserGroup(),
			steamid = ply:SteamID(),
			steamid64 = ply:SteamID64(),
		}
	else
		profilePlayer = {
			name = tbl.name,
			steamid = tbl.steamid,
			steamid64 = tbl.steamid64,
		}
	end

	self.menu.frame:Add("TicSys.userProfile")
end

local PANEL = {}
function PANEL:Init()
	self:SetPos(self:GetParent():GetWide(),0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())
	self.Paint = function(self)
		draw.RoundedBox(8, 0, 0, self:GetWide(), self:GetTall(), Color(236,236,236))
	end
	self:SetZPos(1)
	self:MoveToFront()

	self.profilePlayer = profilePlayer

	self:loadPanel()
	self:MoveTo(250,0,0.4)

	table.insert(TicSys.panels, self)
end

function PANEL:loadPanel()
	local title = self:TicSysTitle(TicSys.lang["User Profile"], "materials/ticsys/user.png")

	self.rank = TicSys:getRank(self.profilePlayer.steamid)
	if self.rank then
		local label = title:TicSysLabel("  "..self.rank.rank.."  ","TicSys.17Bold",false,false,false,26,Color(255,255,255),LEFT,{5,9,0,9},true,5)
		label.Paint = function()
			draw.RoundedBox(6, 0, 0, label:GetWide(), label:GetTall(), self.rank.color)
			draw.RoundedBox(6, 0, 0, label:GetWide(), label:GetTall(), Color(0,0,0,30))
		end
	end

	self:loadInfoPlayer()

	if TicSys:isOwner(LocalPlayer()) || TicSys:isAdmin(LocalPlayer()) then
		self:loadTickets()
	end

	local closeButton = self:TicSysButton("","TicSys.20",self:GetWide()-51,5,40,40,Color(255,255,255))
	closeButton.Paint = function(self)
		surface.SetMaterial( Material("materials/ticsys/close.png") )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect(5, 5, 30, 30 )
	end
	closeButton.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		self:MoveTo(self:GetParent():GetWide(),0,0.4,0,-1,function()
			self:Remove()
		end)
	end
end

function PANEL:loadInfoPlayer()
	local box = self:TicSysBox(208, TicSys.lang["User Information"], 10)

	box:TicSysLabel( "• "..TicSys.lang["Name"]..": "..self.profilePlayer.name, "TicSys.20Bold", 0, 0, false, false, Color(62,82,111), TOP, {190,31,0,0}, true)
	if self.profilePlayer.group then box:TicSysLabel( "• "..TicSys.lang["Group"]..": "..self.profilePlayer.group, "TicSys.20Bold", 0, 0, false, false, Color(62,82,111), TOP, {190,4,0,0}, true) end

	local urlProfile = box:TicSysButton("• "..TicSys.lang["Profile"]..": steamcommunity.com/profiles/"..self.profilePlayer.steamid64,"TicSys.20Bold",false,false,false,false,Color(62,82,111),TOP,{190,4,0,0},false,4)
	urlProfile:SetDrawBackground(false)
	urlProfile.DoClick = function()
		gui.OpenURL("https://steamcommunity.com/profiles/"..self.profilePlayer.steamid64)
	end
	urlProfile.OnCursorEntered = function()
		urlProfile:SetColor(Color(79,148,178))
	end
	urlProfile.OnCursorExited = function()
		urlProfile:SetColor(Color(62,82,111))
	end

	box:TicSysLabel( "• "..TicSys.lang["Count Send Tickets"]..": "..TicSys:getSendTickets(self.profilePlayer.steamid), "TicSys.20Bold", 0, 0, false, false, Color(62,82,111), TOP, {190,4,0,0}, true)
	box:TicSysLabel( "• "..TicSys.lang["Count Solved Tickets"]..": "..TicSys:getSolvedTickets(self.profilePlayer.steamid), "TicSys.20Bold", 0, 0, false, false, Color(62,82,111), TOP, {190,4,0,0}, true)
	box:TicSysLabel( "• "..TicSys.lang["Reputation"]..": "..TicSys:getReputation(self.profilePlayer.steamid).."/5", "TicSys.20Bold", 0, 0, false, false, Color(62,82,111), TOP, {190,4,0,0}, true)

	if self.rank then
		box:TicSysAvatar(true, 20, 30, 150, 150, false, self.profilePlayer.steamid64, false, false, true, self.rank.color)
	else
		box:TicSysAvatar(true, 20, 30, 150, 150, false, self.profilePlayer.steamid64, false, false, true)
	end
end

function PANEL:loadTickets()
	local box = self:TicSysBox(435, TicSys.lang["All Tickets"], 10)

	box:TicSysCategories({10,30,10,5}, true, true, false, true, true)

	local scroll = box:TicSysScroll({10,0,10,20})

	for k,v in pairs(table.Reverse(TicSys.tickets)) do
		if (v.verifier && v.verifier.steamid == self.profilePlayer.steamid) || v.caller.steamid == self.profilePlayer.steamid then
			scroll:TicSysLine(v, true, true, false, true, true)
		end
	end
end

vgui.Register( "TicSys.userProfile", PANEL, "Panel" )