local PANEL = {}
function PANEL:Init()
	self:SetPos(250,0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())

	self:loadPanel()
end

function PANEL:loadPanel()
	self:TicSysTitle()
	self:addList()
end

function PANEL:addList()
	local box = self:TicSysScroll({5,5,5,5})
	for k,v in pairs(player.GetAll()) do
		if TicSys:isOwner(v) || TicSys:isAdmin(v) then
			self:addAdmin(box, v)
		end
	end
end

function PANEL:addAdmin(parent, ply)
	local line = vgui.Create("DPanel",parent)
	line:Dock(TOP)
	line:DockMargin(0,0,0,5)
	line:SetTall(36)
	line.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))
		if !IsValid(ply) then self:Remove() end
	end

	line:TicSysAvatar(false, 3, 3, 30, 30, ply)

	line:TicSysLabel(ply:Name(),"TicSys.20",false,false,160,false,Color(255,255,255),LEFT,{40,0,0,0})
	line:TicSysLabel(ply:GetUserGroup(),"TicSys.20",false,false,150,false,Color(255,255,255),LEFT,{25,0,0,0})

	local rank = TicSys:getRank(ply:SteamID())
	if rank then
		local label = line:TicSysLabel("  "..rank.rank.."  ","TicSys.17Bold",false,false,false,false,Color(255,255,255),LEFT,{25,7,0,7},true,5)
		label.Paint = function(self)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), rank.color)
			draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(0,0,0,30))
		end
	end

	local openProfile = line:TicSysButton(" "..TicSys.lang["Open Profile"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
	openProfile.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	openProfile.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		TicSys:openProfile(ply)
	end
	openProfile:TicSysHoverEffect()
end

vgui.Register( "TicSys.onlineAdmins", PANEL, "Panel" )