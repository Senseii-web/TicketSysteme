local PANEL = {}
function PANEL:Init()
	self:SetPos(250,0)
	self:SetSize(self:GetParent():GetWide()-250,self:GetParent():GetTall())

	self:loadPanel()
end

function PANEL:loadPanel()
	self:Clear()

	self.ticket = {}
	self.ticket.url = {}

	self:TicSysTitle()
	self:boxSelectPlayer()
	self:boxDescription()
	self:boxFiles()
	self:btnSendTicket()
end

function PANEL:sendTicket()
	if !self.ticket.shortReason then surface.PlaySound( "buttons/button10.wav" ) return end
	if !IsValid(self.ticket.player) && !self.ticket.otherinfo then
		self.ticket.player = LocalPlayer()
	end
	if !self.ticket.description then
		self.ticket.description = ""
	end

	surface.PlaySound( "buttons/button15.wav" )

	net.Start("TicSys.newTicket")
	net.WriteTable(self.ticket)
	net.SendToServer()
end

function PANEL:btnSendTicket()
	local sendTicket = self:TicSysButton(TicSys.lang["Send Ticket"],"TicSys.20",false,false,false,30,Color(255,255,255),TOP,{15,0,15,0})
	sendTicket.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(199,142,56))
	end
	sendTicket.DoClick = function()
		self:sendTicket()
	end
	sendTicket:TicSysHoverEffect()
end

function PANEL:boxFiles()
	local box = self:TicSysBox(256, TicSys.lang["Files"], 5)

	local listFiles = vgui.Create( "DListView", box )
	listFiles:SetTall(box:GetTall()-120)
	listFiles:Dock( TOP )
	listFiles:DockMargin(15,30,15,0)
	listFiles:SetMultiSelect( false )
	listFiles:AddColumn( TicSys.lang["URL"] )
	listFiles:SortByColumn(1)
	function listFiles:getCount()
		local count = 0
		for k, line in pairs( self:GetLines() ) do
			count = count + 1
		end
		return count
	end

	local stringUrl = vgui.Create( "DTextEntry", box )
	stringUrl:SetTall( 30 )
	stringUrl:Dock(TOP)
	stringUrl:DockMargin(15,7,15,0)
	stringUrl:SetPlaceholderText( TicSys.lang["Add Url Desc"] )

	local addUrl = box:TicSysButton(TicSys.lang["Add Url Btn"],"TicSys.20",false,false,341,false,Color(255,255,255),LEFT,{15,7,0,25})
	addUrl.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	addUrl.DoClick = function()
		if listFiles:getCount() >= TicSys.cfg["Max Count Files"] || string.len(stringUrl:GetValue()) < 1 then return end
		surface.PlaySound( "buttons/button15.wav" )
		listFiles:AddLine(stringUrl:GetValue())
		table.insert(self.ticket.url,stringUrl:GetValue())
	end
	addUrl:TicSysHoverEffect()

	local removeUrl = box:TicSysButton(TicSys.lang["Remove Url Btn"],"TicSys.20",false,false,341,false,Color(255,255,255),LEFT,{7,7,0,25})
	removeUrl.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
	end
	removeUrl.DoClick = function()
		if listFiles:GetSelectedLine() == nil then return end
		surface.PlaySound( "buttons/button15.wav" )
		table.RemoveByValue(self.ticket.url,listFiles:GetLine(listFiles:GetSelectedLine()):GetValue(1))
		listFiles:RemoveLine(listFiles:GetSelectedLine())
	end
	removeUrl:TicSysHoverEffect()
end

function PANEL:boxDescription()
	local box = self:TicSysBox(256, TicSys.lang["Description"], 5)

	local reasonList = vgui.Create( "DComboBox",box )
	reasonList:SetTall( 30 )
	reasonList:Dock(TOP)
	reasonList:DockMargin(15,30,15,0)
	reasonList:SetValue( TicSys.lang["Short Reason"] )
	reasonList:SetSortItems(false)
	reasonList.OnSelect = function( panel, value, data )
		self.ticket.shortReason = reasonList:GetValue()
	end
	for k, v in pairs( TicSys.cfg["Short Reason"] ) do
		reasonList:AddChoice( v )
	end

	local description = vgui.Create( "DTextEntry", box )
	description:SetTall( 165 )
	description:Dock(TOP)
	description:DockMargin(15,5,15,0)
	description:SetMultiline(true)
	description:SetText( "" )
	description.MaxChars = TicSys.cfg["Length Description"]
	description.OnChange = function()
		local txt = description:GetValue()
		local amt = string.len(txt)
		if amt > description.MaxChars then
			description:SetText(description.OldText)
			description:SetValue(description.OldText)
		else
			description.OldText = txt
		end
		self.ticket.description = txt
	end
end

function PANEL:boxSelectPlayer()
	local box = self:TicSysBox(86, TicSys.lang["Select Player"], 10)

	local selectPlayer = vgui.Create( "DComboBox",box )
	selectPlayer:SetSize( self:GetWide()/2-55, 30 )
	selectPlayer:SetPos(15,30)
	selectPlayer:SetValue( TicSys.lang["Select Player"] )
	selectPlayer.OnSelect = function( panel, value, data )
		local ply = selectPlayer[value-1]
		if IsValid(ply) then
			self.ticket.player = ply
		else
			self.ticket.player = nil
		end
	end
	selectPlayer:AddChoice( TicSys.lang["Player is offline"] )
	for k, v in pairs( player.GetAll() ) do
		selectPlayer:AddChoice( v:Name().." - "..v:SteamID() )
		selectPlayer[k] = v
	end

	local otherInfoPlayer = vgui.Create( "DTextEntry", box )
	otherInfoPlayer:SetSize( self:GetWide()/2-55, 30 )
	otherInfoPlayer:SetPos( self:GetWide()/2+10, 30)
	otherInfoPlayer:SetPlaceholderText( TicSys.lang["Info Player"] )
	otherInfoPlayer.OnChange = function()
		self.ticket.otherinfo = otherInfoPlayer:GetValue()
	end

	local oldPaint = box.Paint
	box.Paint = function(self)
		oldPaint(self)
		draw.SimpleText(TicSys.lang["OR"],"TicSys.20Bold",self:GetWide()/2,45,Color(62,82,111),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	end
end

vgui.Register( "TicSys.newTicket", PANEL, "Panel" )