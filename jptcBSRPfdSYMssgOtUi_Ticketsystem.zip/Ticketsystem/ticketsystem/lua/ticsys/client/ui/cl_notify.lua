local notifyPanel

local function createNotifyPanel()
	notifyPanel = vgui.Create("DPanel")
	notifyPanel:SetSize(400,ScrH()-200)
	notifyPanel:SetPos(ScrW()-notifyPanel:GetWide()-20, 100)
	notifyPanel:SetDrawBackground(false)
end

local function ticketActions(panel, id)
	local ticket
	for k,v in pairs(TicSys.tickets) do
		if tonumber(v.id) == id then
			ticket = v
		end
	end
	if ticket == nil then return end

	local panelActions = vgui.Create("DPanel", panel)
	panelActions:Dock(BOTTOM)
	panelActions:DockMargin(0,0,10,5)
	panelActions:SetTall(24)
	panelActions:SetDrawBackground(false)

	local close = panelActions:TicSysButton(" "..TicSys.lang["Close"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{5,0,0,0},true)
	close.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
	end
	close.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		panel:Remove()
	end
	close:TicSysHoverEffect()

	local viewTicket = panelActions:TicSysButton(" "..TicSys.lang["View"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{5,0,0,0},true)
	viewTicket.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	viewTicket.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )

		if !IsValid(TicSys.menu.frame) then
			TicSys.menu:openMenu()
			TicSys:openTicket(ticket)
		else
			TicSys:openTicket(ticket)
		end

		panel:Remove()
	end
	viewTicket:TicSysHoverEffect()

	local takeTicket = panelActions:TicSysButton(" "..TicSys.lang["Take Ticket"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,false,true)
	takeTicket.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	takeTicket.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		
		net.Start("TicSys.takeTicket")
		net.WriteTable(ticket)
		net.SendToServer()

		if !IsValid(TicSys.menu.frame) then
			TicSys.menu:openMenu()
			TicSys:openTicket(ticket)
		else
			TicSys:openTicket(ticket)
		end

		panel:Remove()
	end
	takeTicket:TicSysHoverEffect()

	local newDockLeft = (takeTicket:GetWide()+viewTicket:GetWide()+close:GetWide()) >= panel.label:GetWide() and (takeTicket:GetWide()+viewTicket:GetWide()+close:GetWide()+29) or (panel.label:GetWide()+20)
	panel:DockMargin(notifyPanel:GetWide()-newDockLeft,5,0,0)
	panel:SetTall(panel:GetTall()+31)
end

function TicSys:addNotify(msg, ntf_type, id)
	if notifyPanel == nil || !IsValid(notifyPanel) then
		createNotifyPanel()
	end

	local color = Color(62,82,111)
	local chatColor = Color(200,200,200)
	if ntf_type == 1 then
		color = Color(77,168,148)
		chatColor = Color(77,168,148)
	elseif ntf_type == 2 then
		color = Color(168,77,77)
		chatColor = Color(168,77,77)
	end

	chat.AddText(chatColor, TicSys.lang["Tag"].." "..msg)

	local time = id == 0 and 6 or 30
	local timeRemove = CurTime() + time

	local panel = vgui.Create("DPanel", notifyPanel)
	panel:Dock(TOP)
	panel:DockMargin(0,5,0,0)
	panel:DockPadding(7,2,2,2)
	panel:SetTall(60)
	panel.Paint = function(self)
		local h = (self:GetTall()-6)*((timeRemove-CurTime())*100/time)/100

		draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(236,236,236))
		draw.RoundedBox(0, self:GetWide()-6, self:GetTall()-h-3, 3, h, color)

		surface.SetDrawColor( 83,83,83,100 )
		surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
	end
	panel:SetAlpha(0)
	panel:AlphaTo(255,0.2)

	panel.label = panel:TicSysLabel(msg, "TicSys.20", 0, 0, false, false, color, TOP, {0,4,0,0}, true)

	panel:SetTall(panel.label:GetTall()+12)
	panel:DockMargin(notifyPanel:GetWide()-panel.label:GetWide()-20,5,0,0)

	if id != 0 then ticketActions(panel, id) end

	timer.Simple(time, function()
		if IsValid(panel) then
			panel:AlphaTo(0,0.2,0, function()
				panel:Remove()
			end)
		end
		if IsValid(notifyPanel) && #notifyPanel:GetChildren() < 1 then
			notifyPanel:Remove()
		end
	end)

	surface.PlaySound( "buttons/button14.wav" )
end