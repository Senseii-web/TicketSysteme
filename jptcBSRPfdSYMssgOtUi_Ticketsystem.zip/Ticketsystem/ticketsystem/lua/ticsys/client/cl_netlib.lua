net.Receive("TicSys.reloadCfg",function()
	TicSys.cfg = net.ReadTable()
	TicSys.lang = net.ReadTable()

	if IsValid(TicSys.menu.frame) && IsValid(TicSys.menu.frame.settingsPanel) then
		TicSys.menu.frame.settingsPanel:Clear()
		TicSys.menu.frame.settingsPanel:loadPanel()
	end
end)

net.Receive("TicSys.openMenu",function()
	local len = net.ReadUInt(32)
	TicSys.tickets = util.JSONToTable(util.Decompress(net.ReadData(len)))
	TicSys.panels = {}

	TicSys.menu:openMenu()
end)

net.Receive("TicSys.notify",function()
	TicSys:addNotify(net.ReadString(), net.ReadInt(3), net.ReadInt(16))
end)

net.Receive("TicSys.updateTicket",function()
	local ticket = net.ReadTable()
	local isFound = false
	if !TicSys.tickets then return end
	for k,v in pairs(TicSys.tickets) do
		if v.id == ticket.id then
			TicSys.tickets[k] = ticket
			isFound = true
		end
	end
	if !isFound then table.insert(TicSys.tickets, ticket) end
	TicSys:updatePanels()
end)