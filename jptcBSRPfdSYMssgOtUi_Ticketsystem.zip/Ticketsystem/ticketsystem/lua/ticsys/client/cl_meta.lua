local PANEL = FindMetaTable("Panel")

function PANEL:TicSysHoverEffect()
	self.alpha = 0
	self.OnCursorEntered = function()
		self.isHover = true
	end
	self.OnCursorExited = function()
		self.isHover = false
	end

	local oldPaint = self.Paint
	self.Paint = function(self)
		oldPaint(self)

		if self.isHover then 
			self.alpha = math.Approach(self.alpha, 55, 1.2)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,self.alpha)) 
		else
			self.alpha = math.Approach(self.alpha, 0, 1.2)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,self.alpha)) 
		end
	end
end

function PANEL:TicSysToggleFilters()
	if self:GetTall() == 0 then
		self.canUse = false
		self:SizeTo(self:GetWide(),250,0.3,0,-1, function()
			self.canUse = true
		end)
		self:DockMargin(15,10,15,0)
	elseif self.canUse then
		self.canUse = false
		self:SizeTo(self:GetWide(),0,0.3,0,-1, function()
			self:DockMargin(15,0,15,0)
			self.canUse = true
		end)
	end
end

function PANEL:TicSysFilters()
	local selectPlayer = vgui.Create( "DComboBox",self )
	selectPlayer:SetSize( self:GetParent():GetWide()/2-55, 30 )
	selectPlayer:SetPos(15,30)
	selectPlayer:SetValue( TicSys.lang["Select Player"] )
	selectPlayer.OnSelect = function( panel, value, data )
		local ply = selectPlayer[value-1]
		if IsValid(ply) then
			self:GetParent().filters.player = ply
		else
			self:GetParent().filters.player = nil
		end
	end
	selectPlayer:AddChoice( TicSys.lang["Player is offline"] )
	for k, v in pairs( player.GetAll() ) do
		selectPlayer:AddChoice( v:Name().." - "..v:SteamID() )
		selectPlayer[k] = v
	end

	local otherInfoPlayer = vgui.Create( "DTextEntry", self )
	otherInfoPlayer:SetSize( self:GetParent():GetWide()/2-55, 30 )
	otherInfoPlayer:SetPos( self:GetParent():GetWide()/2+10, 30)
	otherInfoPlayer:SetPlaceholderText( TicSys.lang["Find Player"] )
	otherInfoPlayer.OnChange = function()
		self:GetParent().filters.otherInfoPlayer = otherInfoPlayer:GetValue()
	end

	local oldPaint = self.Paint
	self.Paint = function()
		oldPaint(self)
		draw.SimpleText(TicSys.lang["OR"],"TicSys.20Bold",self:GetWide()/2,45,Color(62,82,111),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	end

	local selectType = vgui.Create( "DComboBox",self )
	selectType:SetTall( 30 )
	selectType:Dock(TOP)
	selectType:DockMargin(15,70,15,0)
	selectType:SetValue( TicSys.lang["Select Type"] )
	selectType.OnSelect = function( panel, value, data )
		self:GetParent().filters.type = value
	end
	selectType:SetSortItems(false)
	selectType:AddChoice( TicSys.lang["ctg.caller"] )
	selectType:AddChoice( TicSys.lang["ctg.violator"] )
	selectType:AddChoice( TicSys.lang["ctg.verifier"] )

	local reasonList = vgui.Create( "DComboBox",self )
	reasonList:SetTall( 30 )
	reasonList:Dock(TOP)
	reasonList:DockMargin(15,10,15,0)
	reasonList:SetValue( TicSys.lang["Short Reason"] )
	reasonList:SetSortItems(false)
	reasonList.OnSelect = function( panel, value, data )
		self:GetParent().filters.reason = data
	end
	reasonList:AddChoice( TicSys.lang["All"] )
	for k, v in pairs( TicSys.cfg["Short Reason"] ) do
		reasonList:AddChoice( v )
	end

	local timeTicket = vgui.Create( "DComboBox",self )
	timeTicket:SetSize( self:GetParent():GetWide()/2-45, 30 )
	timeTicket:Dock(TOP)
	timeTicket:DockMargin(15,10,15,0)
	timeTicket:SetValue( TicSys.lang["Select Time"] )
	timeTicket.OnSelect = function( panel, value, data )
		self:GetParent().filters.time = timeTicket[value]
	end
	timeTicket:SetSortItems(false)
	for i=1,TicSys.cfg["Load Ticket Last ? Days"] do
		local time = os.time() - 86400*(i-1)
		timeTicket:AddChoice( os.date(TicSys.cfg["Format Date"], time) )
		timeTicket[i] = os.time({year = 2019,month = os.date("%m",time),day = os.date("%d",time),hour = 0,min = 0,sec = 0})
	end

	local find = self:TicSysButton("  "..TicSys.lang["Find"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,10,15,25},true)
	find.Paint = function()
		draw.RoundedBox(6, 0, 0, find:GetWide(), find:GetTall(), Color(77,168,148))
	end
	find.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		self:GetParent():loadTickets()
	end
	find:TicSysHoverEffect()

	local reset = self:TicSysButton("  "..TicSys.lang["Reset"].."  ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,10,10,25},true)
	reset.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,77))
	end
	reset.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )

		selectPlayer:SetValue( TicSys.lang["Select Player"] )
		timeTicket:SetValue( TicSys.lang["Select Time"] )
		reasonList:SetValue( TicSys.lang["Short Reason"] )
		selectType:SetValue( TicSys.lang["Select Type"] )
		otherInfoPlayer:SetText( "" )

		self:GetParent().filters = {}
		self:GetParent():loadTickets()
	end
	reset:TicSysHoverEffect()
end

function PANEL:TicSysTitle(title, icon)
	local title = title || self:GetParent().activeTabInfo.title
	local icon = icon || self:GetParent().activeTabInfo.icon

	local main = vgui.Create("DPanel", self)
	main:SetPos(5,5)
	main:SetTall(40)
	main:Dock(TOP)
	main:DockMargin(5,5,5,0)
	main.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111))

		surface.SetMaterial( Material(icon) )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect(6, 6, 28, 28 )
	end

	main:TicSysLabel(title,"TicSys.20",false,false,false,40,Color(255,255,255),LEFT,{42,0,5,0},true)

	return main
end

function PANEL:TicSysButton(text, font, posX, posY, sizeX, sizeY, color, dock, dockmargin, isSizeToContent, align)
	local button = vgui.Create( "DButton", self )
	if dock then
		button:Dock(dock)
		if dockmargin then
			button:DockMargin(dockmargin[1], dockmargin[2], dockmargin[3], dockmargin[4])
		end
	end
	button:SetColor(color)
	button:SetFont(font)
	button:SetText(text)
	if sizeX then
		button:SetWide(sizeX)
	end
	if sizeY then
		button:SetTall(sizeY)
	end
	if posX && posY then
		button:SetPos(posX, posY)
	end
	if isSizeToContent then
		if !sizeX && !sizeY then
			button:SizeToContents()
		else
			if !sizeX then
				button:SizeToContentsX()
			end
			if !sizeY then
				button:SizeToContentsY()
			end
		end
	end
	if align then
		button:SetContentAlignment(align)
	end

	return button
end

function PANEL:TicSysLabel(text, font, posX, posY, sizeX, sizeY, color, dock, dockmargin, isSizeToContent, align)
	local label = vgui.Create( "DLabel", self )
	if dock then
		label:Dock(dock)
		if dockmargin then
			label:DockMargin(dockmargin[1], dockmargin[2], dockmargin[3], dockmargin[4])
		end
	end
	label:SetColor(color)
	label:SetFont(font)
	label:SetText(text)
	if sizeX then
		label:SetWide(sizeX)
	end
	if sizeY then
		label:SetTall(sizeY)
	end
	if posX && posY then
		label:SetPos(posX, posY)
	end
	if isSizeToContent then
		if !sizeX then
			label:SizeToContentsX()
		end
		if !sizeY then
			label:SizeToContentsY()
		end
	end
	if align then
		label:SetContentAlignment(align)
	end
	label:SetTooltip(TicSys.lang["Right click"])
	label:SetMouseInputEnabled(true)
	function label:DoRightClick()
		SetClipboardText(string.Trim(self:GetText()))
	end

	return label
end

function PANEL:TicSysScroll(dockmargin)
	local scroll = vgui.Create("DScrollPanel", self)
	scroll:Dock(FILL)
	if dockmargin then
		scroll:DockMargin(dockmargin[1],dockmargin[2],dockmargin[3],dockmargin[4])
	end
	function scroll:Paint(w, h) end
	local scrollbar = scroll:GetVBar()
	function scrollbar:Paint(w, h) end
	function scrollbar.btnUp:Paint(w, h)
		draw.RoundedBox(3, 4, 0, w-4, h, Color(62,82,111,255))
	end
	function scrollbar.btnDown:Paint(w, h)
		draw.RoundedBox(3, 4, 0, w-4, h, Color(62,82,111,255))
	end
	function scrollbar.btnGrip:Paint(w, h)
		draw.RoundedBox(3, 4, 5, w-4, h-10, Color(62,82,111,255))
	end

	return scroll
end

function PANEL:TicSysAvatar(isCircle, posX, posY, sizeX, sizeY, ply, steamid64, dock, dockmargin, defcolor, defborder)
	local avatar
	avatar = vgui.Create( "AvatarImage", self )
	if posX && posY then
		avatar:SetPos(posX, posY)
	end
	avatar:SetSize( sizeX, sizeY )
	if dock then
		avatar:Dock(dock)
		avatar:DockMargin(dockmargin[1], dockmargin[2], dockmargin[3], dockmargin[4])
	end
	if steamid64 then
		avatar:SetSteamID(steamid64, sizeX)
	end
	if ply then
		avatar:SetPlayer(ply, sizeX)
	end

	if isCircle then
		local pnl = vgui.Create("DPanel",avatar)
		pnl:Dock(FILL)
		pnl.Paint = function()
		    surface.SetMaterial( Material("materials/ticsys/circle"..sizeX..".png") )
		    if defcolor then
		    	surface.SetDrawColor( 236,236,236,255 )
		    else
		    	surface.SetDrawColor( 62,82,111,255 )
		    end
		    surface.DrawTexturedRect(0, 0, sizeX, sizeX )

			if defborder then
			    surface.SetMaterial( Material("materials/ticsys/circleborder.png") )
			    surface.SetDrawColor( defborder )
			    surface.DrawTexturedRect(0, 0, 150, 150 )
			end
		end
	end

	return avatar
end

function PANEL:TicSysCategories(dockmargin, isCaller, isViolator, isVerifier, isReason, isSolved)
	local category = vgui.Create("DPanel",self)
	category:Dock(TOP)
	category:DockMargin(dockmargin[1],dockmargin[2],dockmargin[3],dockmargin[4])
	category:SetTall(24)
	category.Paint = function(self)
		draw.RoundedBox(3, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111,255))
	end
	category:TicSysLabel(TicSys.lang["ctg.id"], "TicSys.17Bold", false, false, 60, 24, Color(255,255,255), LEFT, {9,0,0,0}, false)
	local marginLeft = 10
	if isCaller then category:TicSysLabel(TicSys.lang["ctg.caller"], "TicSys.17Bold", false, false, 110, 24, Color(255,255,255), LEFT, {10,0,0,0}, false) marginLeft = 35 end
	if isViolator then category:TicSysLabel(TicSys.lang["ctg.violator"], "TicSys.17Bold", false, false, 110, 24, Color(255,255,255), LEFT, {marginLeft,0,0,0}, false) end
	if isVerifier then category:TicSysLabel(TicSys.lang["ctg.verifier"], "TicSys.17Bold", false, false, 110, 24, Color(255,255,255), LEFT, {35,0,0,0}, false) end
	if isReason then category:TicSysLabel(TicSys.lang["ctg.reason"], "TicSys.17Bold", false, false, 110, 24, Color(255,255,255), LEFT, {35,0,0,0}, false) end
	if isSolved then category:TicSysLabel(TicSys.lang["ctg.solved"], "TicSys.17Bold", false, false, 100, 24, Color(255,255,255), LEFT, {11,0,0,0}, false) end
end

function PANEL:TicSysLine(v, isCaller, isViolator, isVerifier, isReason, isSolved)
	local line = vgui.Create("DPanel",self)
	line:Dock(TOP)
	line:DockMargin(0,0,0,5)
	line:SetTall(36)
	line.Paint = function(self)
		draw.RoundedBox(3, 0, 0, self:GetWide(), self:GetTall(), Color(62,82,111,255))
	end

	line:TicSysLabel("##"..v.id, "TicSys.17Bold", false, false, 60, 36, Color(255,255,255), LEFT, {10,0,0,0}, false)
	if isCaller then
		line:TicSysAvatar(true, false, false, 20, 20, false, v.caller.steamid64, LEFT, {10,8,0,8})
		line:TicSysLabel(v.caller.name, "TicSys.17Bold", false, false, 110, 36, Color(255,255,255), LEFT, {5,0,0,0}, false)
	end
	if isViolator && (v.violator.name != "" && v.violator.steamid64 != "") then
		line:TicSysAvatar(true, false, false, 20, 20, false, v.violator.steamid64, LEFT, {10,8,0,8})
		line:TicSysLabel(v.violator.name, "TicSys.17Bold", false, false, 110, 36, Color(255,255,255), LEFT, {5,0,0,0}, false)
	else
		line:TicSysLabel(v.violator.otherinfo, "TicSys.17Bold", false, false, 135, 36, Color(255,255,255), LEFT, {10,0,0,0}, false)
	end
	if isVerifier then
		if !v.verifier then
			line:TicSysLabel(TicSys.lang["Not taken"], "TicSys.17Bold", false, false, 135, 36, Color(205,177,64), LEFT, {10,0,0,0}, false)
		else
			line:TicSysAvatar(true, false, false, 20, 20, false, v.verifier.steamid64, LEFT, {10,8,0,8})
			line:TicSysLabel(v.verifier.name, "TicSys.17Bold", false, false, 110, 36, Color(255,255,255), LEFT, {5,0,0,0}, false)
		end
	end
	if isReason then
		line:TicSysLabel(v.shortReason, "TicSys.17Bold", false, false, 110, 36, Color(255,255,255), LEFT, {10,0,0,0}, false)
	end

	if isSolved then
		local textSolved = TicSys.lang["Not Solved"]
		local colorSolved = Color(205,92,92)
		if v.isSolved == "1" then
			textSolved = TicSys.lang["Solved"]
			colorSolved = Color(140,205,92)
		end

		line:TicSysLabel(textSolved, "TicSys.17Bold", false, false, 100, 36, colorSolved, LEFT, {10,0,0,0}, true)
	end

	local view = line:TicSysButton(" "..TicSys.lang["View"].." ","TicSys.20",false,false,false,false,Color(255,255,255),RIGHT,{0,4,4,4},true)
	view.Paint = function(self)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(77,168,148))
	end
	view.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		TicSys:openTicket(v)
	end
	view:TicSysHoverEffect()
end

function PANEL:TicSysBox(height, text, docktop)
	local box = vgui.Create("DPanel", self)
	box:Dock(TOP)
	box:DockMargin(15,docktop,15,0)
	box:SetTall(height)
	box.Paint = function(self)
		draw.RoundedBox(6, 0, 12, self:GetWide(), self:GetTall()-24, Color(62,82,111))
		draw.RoundedBox(6, 2, 14, self:GetWide()-4, self:GetTall()-28, Color(236,236,236))
	end

	local label = box:TicSysLabel("   "..text.."   ", "TicSys.20Bold", 40, 0, false, false, Color(62,82,111,255), false, false, true)
	label.Paint = function(self)
		draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(236,236,236))
	end

	return box
end