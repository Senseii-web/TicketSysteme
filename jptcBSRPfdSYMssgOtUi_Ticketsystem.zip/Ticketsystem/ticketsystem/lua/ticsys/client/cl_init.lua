TicSys.menu = {}
TicSys.tickets = {}
TicSys.panels = {}

list.Add("DesktopWindows",{
	icon = "materials/ticsys/tsicon.png",
	init = function()
		net.Start("TicSys.contextMenuButton")
		net.SendToServer()
	end,
	title = "Ticket System",
})

hook.Add("Think","TicSys.isGameUIVisible",function()
	if IsValid(TicSys.menu.frame) then
		-- if input.IsKeyDown(KEY_ESCAPE) then
		-- 	TicSys.menu.frame:Close()
		-- 	gui.HideGameUI()
		-- end
		if gui.IsGameUIVisible() || gui.IsConsoleVisible() then
			TicSys.menu.frame:Hide()
		else
			TicSys.menu.frame:Show()
		end
	end
end)

function TicSys.menu:openMenu()
	if IsValid(self.frame) then self.frame:Remove() end

	self.frame = vgui.Create("DFrame")
	self.frame:SetSize(1000,710)
	self.frame:SetPos(ScrW()/2-self.frame:GetWide()/2, ScrH()/2-self.frame:GetTall()/2)
	self.frame:SetDraggable(false)
	self.frame:MakePopup()
	self.frame:ShowCloseButton(false)
	self.frame:SetTitle("")
	self.frame:SetAlpha(0)
	self.frame.Paint = function(self)
		draw.RoundedBox(8, 0, 0, 250, self:GetTall(), Color(36,36,36,200))
		draw.RoundedBox(8, 1, 1, 250, self:GetTall()-2, Color(62,82,111))
		draw.RoundedBox(8, 250, 0, self:GetWide()-250, self:GetTall(), Color(236,236,236))

		surface.SetMaterial( Material("materials/ticsys/title.png") )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect(15, 12, 32, 32 )

		draw.SimpleText(TicSys.cfg["Title"],"TicSys.31",54,27,Color(255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
	end
	self.frame:AlphaTo(255,0.22)

	local closeFrame = self.frame:TicSysButton(TicSys.lang["Close"],"TicSys.20",5,self.frame:GetTall()-25,241,20,Color(255,255,255))
	closeFrame.Paint = function(self)
		draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), Color( 185,72,72 ) )
	end
	closeFrame.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		self.frame:AlphaTo(0,0.22,0,function()
			self.frame:Remove()
		end)
	end
	closeFrame:TicSysHoverEffect()

	local notifyToggle = self.frame:TicSysButton(TicSys.lang["Close"],"TicSys.20",5,self.frame:GetTall()-50,241,20,Color(255,255,255))
	notifyToggle.Paint = function(self)
		if LocalPlayer():GetNWBool("isTicSysNotify") then
			self:SetText(TicSys.lang["Disable Notifications"])
		else
			self:SetText(TicSys.lang["Enable Notifications"])
		end
		draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), Color(168,77,130))
	end
	notifyToggle.DoClick = function()
		surface.PlaySound( "buttons/button15.wav" )
		net.Start("TicSys.toggleNotify")
		net.SendToServer()
	end
	notifyToggle:TicSysHoverEffect()

	self:createMenu()
end

function TicSys.menu:createMenu()
	local tabs = {
		{title = TicSys.lang["New Ticket"], icon = "materials/ticsys/newticket.png", id = "TicSys.newTicket", first = true},
		{title = TicSys.lang["My Tickets"], icon = "materials/ticsys/mytickets.png", id = "TicSys.myTickets"},
		{title = TicSys.lang["Statistics"], icon = "materials/ticsys/statistics.png", id = "TicSys.statistics"},
		{title = TicSys.lang["Online Admins"], icon = "materials/ticsys/online.png", id = "TicSys.onlineAdmins"},
		{title = TicSys.lang["All Tickets"], icon = "materials/ticsys/alltickets.png", id = "TicSys.allTickets", onlyAdmins = true},
		{title = TicSys.lang["History"], icon = "materials/ticsys/history.png", id = "TicSys.history", onlyAdmins = true},
		{title = TicSys.lang["Settings"], icon = "materials/ticsys/settings.png", id = "TicSys.settings", onlyOwner = true},
	}

	local menuList = vgui.Create("DPanel", self.frame)
	menuList:SetSize(250,self.frame:GetTall()-110)
	menuList:SetPos(0,50)
	menuList:SetDrawBackground(false)

	for k,v in pairs(tabs) do
		if v.onlyOwner then
			if !TicSys:isOwner(LocalPlayer()) then continue end
		end
		if v.onlyAdmins then
			if !TicSys:isAdmin(LocalPlayer()) && !TicSys:isOwner(LocalPlayer()) then continue end
		end

		local button = menuList:TicSysButton("","TicSys.20",false,false,false,50,Color(255,255,255),TOP,{5,5,5,0})
		button.alpha = 0
		button.Paint = function()
			draw.RoundedBox(4, 0, 0, button:GetWide(), button:GetTall(), Color(77,168,148))
			if button == self.frame.activeButton then
				draw.RoundedBox(4,0,0,button:GetWide(),button:GetTall(),Color(0,0,0,90)) 
				draw.RoundedBox(4, button:GetWide()-6, 3, 3, button:GetTall()-6, Color(255,255,255))
			end

			if button.isHover then 
				button.alpha = math.Approach(button.alpha, 55, 1.2)
				draw.RoundedBox(0,0,0,button:GetWide(),button:GetTall(),Color(0,0,0,button.alpha)) 
			else
				button.alpha = math.Approach(button.alpha, 0, 1.2)
				draw.RoundedBox(0,0,0,button:GetWide(),button:GetTall(),Color(0,0,0,button.alpha)) 
			end

			surface.SetMaterial( Material(v.icon) )
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawTexturedRect(9, 9, 32, 32 )

			draw.SimpleText(v.title,"TicSys.20",50,button:GetTall()/2,Color(255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
		button.OnCursorEntered = function()
			button.isHover = true
		end
		button.OnCursorExited = function()
			button.isHover = false
		end
		button.DoClick = function()
			if IsValid(self.frame.activeTabPanel) then self.frame.activeTabPanel:Remove() end
			surface.PlaySound( "buttons/button15.wav" )
			self.frame.activeTabInfo = v
			self.frame.activeTabPanel = self.frame:Add(v.id)
			self.frame.activeButton = button
		end
		if v.first then
			self.frame.activeTabInfo = v
			self.frame.activeTabPanel = self.frame:Add(v.id)
			self.frame.activeButton = button
		end
	end
end