function TicSys:isOwner(ply)
	if #TicSys.cfg["Owner Groups"] == 0 then 
		if ply:IsSuperAdmin() then return true end
	end
	if table.HasValue(TicSys.cfg["Owner Groups"],ply:GetUserGroup()) then
		return true
	end
	return false
end

function TicSys:isAdmin(ply)
	if table.HasValue(TicSys.cfg["Admin Groups"],ply:GetUserGroup()) then
		return true
	end
	return false
end